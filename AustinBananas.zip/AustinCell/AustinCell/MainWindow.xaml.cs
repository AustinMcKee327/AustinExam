﻿/* Austin McKee
 * June 21, 2019
 * this program compares the two cellphone plans to tell you which one is better
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AustinCell
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double DaytimeTotalA;
        double EveningTotalA;
        double WeekendTotalA;
        double TotalA;
        
        double DaytimeTotalB;
        double EveningTotalB;
        double WeekendTotalB;
        double TotalB;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Output.Content = "";
            int.TryParse(DaytimeText.Text, out int DayMin);
            int.TryParse(EveningText.Text, out int EveMin);
            int.TryParse(WeekendText.Text, out int WKDMin);
            
            //Plan A
            if (DayMin >= 100)
            {
                DaytimeTotalA = (DayMin - 100) * 0.25;
            }
            EveningTotalA = EveMin * 0.15;
            WeekendTotalA = WKDMin * 0.20;
            TotalA = WeekendTotalA + EveningTotalA + DaytimeTotalA;
            Output.Content += "Plan A costs this much: " + TotalA.ToString("#.00") + Environment.NewLine;

            //Plan B
            if (DayMin >= 250)
            {
                DaytimeTotalB = (DayMin - 250) * 0.45;
            }
            EveningTotalB = EveMin * 0.35;
            
            WeekendTotalB = WKDMin * 0.25;
            TotalB = WeekendTotalB + EveningTotalB + DaytimeTotalB;
            Output.Content += "Plan B costs this much: " + TotalB.ToString("#.00") + Environment.NewLine;

            //Which one is better?

           if(TotalA.ToString("#.000")== TotalB.ToString("#.000"))
            {
                Output.Content += "Both Plans Cost the Same";
                
            }
            else
            {
                if (TotalA < TotalB)
                {
                    Output.Content += "Plan B is cheaper";
                }
                else if (TotalB < TotalA)
                {

                    Output.Content += "Plan A is cheaper";
                }
            }
           
           
            
        }
    }
}
