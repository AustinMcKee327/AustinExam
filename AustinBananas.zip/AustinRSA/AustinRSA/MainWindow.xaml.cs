﻿/* Austin McKee
 * June 21, 2019
 * this program finds all RSA numbers withing the users input of range
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AustinRSA
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int lower;
        double lower2;
        int upper;
        int totaldivsors;
        int totalrsa;
        string division;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            int.TryParse(BottomValue.Text, out lower);
            int.TryParse(TopValue.Text, out upper);
            lower2 = lower;
            for(double i = lower; i<=upper; i++)
            {
                for(int j = 1; j<=lower2; j++)
                {
                    division = (lower2 / j).ToString();
                    if (!division.Contains('.'))
                    {
                        totaldivsors++;
                    }
                    if(j == lower2 && totaldivsors == 4)
                    {
                        totalrsa++;
                    }
                }
                lower2++;
                totaldivsors = 0;
            }
            Output.Content = totalrsa;
        }
    }
}
