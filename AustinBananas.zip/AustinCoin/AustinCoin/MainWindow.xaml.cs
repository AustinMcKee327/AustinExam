﻿/* Austin McKee
 * June 21, 2019
 * This program finds all the possibel combanations of coins from 1p to 2 euros 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AustinCoin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int ways;
        int target = 200;
        public MainWindow()
        {
            InitializeComponent();
            for(int a = target; a >= 0; a -= 200)
            {
                for(int b = a; b>=0; b -= 100)
                {
                    for (int c=b; c>=0; c -= 50)
                    {
                        for(int d =c; d>=0; d -= 20)
                        {
                            for (int e=d; e>=0; e -= 10)
                            {
                                for (int f=e; f>=0; f -= 5)
                                {
                                    for(int g=f; g>=0; g -= 2)
                                    {
                                        ways++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Output.Content = ways;
        }
    }
}
