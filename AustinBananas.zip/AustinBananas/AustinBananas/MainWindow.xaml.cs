﻿/* Austin McKee
 * June 21, 2019
 * this program takes human words and tells you if it exsists as a monkey word
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AustinBananas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string input;
        string wordcheck = "Yes";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BananaTranslate_Click(object sender, RoutedEventArgs e)
        {
            input = TextInput.Text.ToUpper();
            char[] word = new char[input.Length];
            wordcheck = "Yes";
            if (word.Length >= 1)
            {
                for (int i = 0; i < input.Length; i++)
                {
                    word[i] = input[i];
                }
                for (int i = 0; i < word.Length; i++)
                {
                    if (word[i] == 'A')
                    {
                        if (i != word.Length - 1)
                        {
                            if (word[i + 1] == 'A')
                            {
                                wordcheck = "No";
                            }
                        }
                    }
                    else if (word[i] == 'B')
                    {
                        if (word[word.Length - 1] != 'S')
                        {
                            wordcheck = "No";
                        }
                        if (i != 0)
                        {
                            wordcheck = "No";
                        }
                    }
                    else if (word[i] == 'N')
                    {
                        if (i != 0)
                        {
                            if (word[i - 1] != 'A')
                            {
                                wordcheck = "No";
                            }
                            if (word[i] != word[word.Length - 1])
                            {
                                if (word[i + 1] != 'A')
                                {
                                    wordcheck = "No";
                                }
                            }
                        }
                        else { wordcheck = "No"; }
                    }
                    else if (word[i] == 'S')
                    {
                        if (word[0] != 'B')
                        {
                            wordcheck = "No";
                        }
                        if (i != word.Length - 1)
                        {
                            wordcheck = "No";
                        }
                    }
                    else
                    {
                        wordcheck = "No";
                    }
                }
            }
            else { wordcheck = "No"; }
            Output.Content += input + "\t" + wordcheck + Environment.NewLine;
        }
    }
    
}
